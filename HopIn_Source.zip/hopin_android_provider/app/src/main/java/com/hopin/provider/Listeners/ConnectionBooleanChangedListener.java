package com.hopin.provider.Listeners;

/**
 * Created by Tranxit Technologies Pvt Ltd, Chennai
 */

public interface ConnectionBooleanChangedListener {
    public void OnMyBooleanChanged();
}
