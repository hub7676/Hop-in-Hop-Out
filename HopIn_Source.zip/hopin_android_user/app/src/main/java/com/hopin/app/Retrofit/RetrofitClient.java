package com.hopin.app.Retrofit;

import com.hopin.app.Helper.URLHelper;
import com.hopin.app.Models.AccessDetails;

import retrofit2.Retrofit;

/**
 * Created by Tranxit Technologies Pvt Ltd, Chennai
 */

public class RetrofitClient {
    private static Retrofit retrofit = null;
    private static Retrofit retrofit_address = null;
    private static Retrofit send_retrofeit = null;


    public static Retrofit getClient() {
        if (retrofit_address==null) {
            retrofit_address = new Retrofit.Builder()
                    .baseUrl(URLHelper.map_address_url)
                    .build();
        }
        return retrofit_address;
    }

    public static Retrofit getLiveTrackingClient() {
        if (retrofit==null) {
            retrofit = new Retrofit.Builder()
                    .baseUrl(AccessDetails.serviceurl)
                    .build();
        }
        return retrofit;
    }

    public static Retrofit sendRequestAPI() {
        if (send_retrofeit==null) {
            send_retrofeit = new Retrofit.Builder()
                    .baseUrl(AccessDetails.serviceurl)
                    .build();
        }
        return send_retrofeit;
    }
}
