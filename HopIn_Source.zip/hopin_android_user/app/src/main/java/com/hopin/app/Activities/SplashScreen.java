package com.hopin.app.Activities;

import android.app.Activity;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.StrictMode;
import android.provider.Settings;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.NetworkError;
import com.android.volley.NetworkResponse;
import com.android.volley.NoConnectionError;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.TimeoutError;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.google.firebase.iid.FirebaseInstanceId;
import com.hopin.app.BuildConfig;
import com.hopin.app.Helper.ConnectionHelper;
import com.hopin.app.Helper.SharedHelper;
import com.hopin.app.Helper.URLHelper;
import com.hopin.app.HopinApplication;
import com.hopin.app.Models.AccessDetails;
import com.hopin.app.R;
import com.hopin.app.Utils.Utilities;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

import static com.hopin.app.HopinApplication.trimMessage;


/**
 * Created by Tranxit Technologies Pvt Ltd, Chennai
 */

public class SplashScreen extends AppCompatActivity {

    public Activity activity = SplashScreen.this;
    public Context context = SplashScreen.this;
    String TAG = "SplashActivity";
    ConnectionHelper helper;
    Boolean isInternet;
    String device_token, device_UDID;
    Handler handleCheckStatus;
    int retryCount = 0;
    AlertDialog alert;
    TextView lblVersion;
    boolean isOpened = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);
        //ForceUpdateChecker.with(this).onUpdateNeeded(this).check();
        ConnectivityManager connectivityManager = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        final NetworkInfo wifiInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_WIFI);
        final NetworkInfo mobileInfo = connectivityManager.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
        helper = new ConnectionHelper(context);
        isInternet = helper.isConnectingToInternet();
        lblVersion = (TextView) findViewById(R.id.lblVersion);
        Log.v("VERSION NAME", ""+BuildConfig.VERSION_NAME);
        Log.v("VERSION CODE", ""+BuildConfig.VERSION_CODE);
        lblVersion.setText(getResources().getString(R.string.version) +" "+ BuildConfig.VERSION_NAME+" ("+BuildConfig.VERSION_CODE+")");

//        getAccess();
        handleCheckStatus = new Handler();
        // check status every 3 sec


        if (Build.VERSION.SDK_INT > 9) {
            StrictMode.ThreadPolicy policy = new StrictMode.ThreadPolicy.Builder().permitAll().build();
            StrictMode.setThreadPolicy(policy);
        }

        handleCheckStatus.postDelayed(new Runnable() {
            @Override
            public void run() {
                Log.w("Handler", "Called");
                if (helper.isConnectingToInternet()) {
                    if (SharedHelper.getKey(context,"loggedIn").equalsIgnoreCase(context.getResources().getString(R.string.True))) {
                            GetToken();
                            accessKeyAPI();
                    }else {
                        if (AccessDetails.demo_build){
                            if (SharedHelper.getKey(SplashScreen.this, "access_username").equalsIgnoreCase("") && SharedHelper.getKey(SplashScreen.this, "access_password").equalsIgnoreCase("")){
                                GoToAccessActivity();
                            }else{
                                accessKeyAPI();
                            }
                        }else{
                            accessKeyAPI();
                        }
                        handleCheckStatus.removeCallbacksAndMessages(null);
                    }
                    if(alert != null && alert.isShowing()){
                        alert.dismiss();
                    }
                }else{
                    showDialog();
                    handleCheckStatus.postDelayed(this, 3000);
                }
            }
        }, 3000);
    }

    public void accessKeyAPI() {

        JSONObject object = new JSONObject();
        try {
            if (AccessDetails.demo_build){
                object.put("username", SharedHelper.getKey(SplashScreen.this, "access_username"));
                object.put("accesskey",SharedHelper.getKey(SplashScreen.this, "access_password"));
            }else{
                object.put("username", AccessDetails.username);
                object.put("accesskey",AccessDetails.password);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, AccessDetails.access_login, object, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                processResponse(response);
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                String json = null;
                String Message;
                NetworkResponse response = error.networkResponse;
                if (response != null && response.data != null) {

                    try {
                        JSONObject errorObj = new JSONObject(new String(response.data));

                        if (response.statusCode == 400 || response.statusCode == 405 || response.statusCode == 500) {
                            try {
                                displayMessage(errorObj.optString("message"));
                            } catch (Exception e) {
                                displayMessage(getString(R.string.something_went_wrong));
                            }
                        } else if (response.statusCode == 401) {
                            displayMessage(errorObj.optString("message"));
                        } else if (response.statusCode == 422) {

                            json = trimMessage(new String(response.data));
                            if (json != "" && json != null) {
                                displayMessage(json);
                            } else {
                                displayMessage(getString(R.string.please_try_again));
                            }
                        } else if (response.statusCode == 503) {
                            displayMessage(getString(R.string.server_down));
                        } else {
                            displayMessage(getString(R.string.please_try_again));
                        }

                    } catch (Exception e) {
                        displayMessage(getString(R.string.something_went_wrong));
                    }

                } else {
                    if (error instanceof NoConnectionError) {
                        displayMessage(getString(R.string.oops_connect_your_internet));
                    } else if (error instanceof NetworkError) {
                        displayMessage(getString(R.string.oops_connect_your_internet));
                    } else if (error instanceof TimeoutError) {
                        displayMessage(getString(R.string.timed_out));
                    }
                }
                if (AccessDetails.demo_build){
                    GoToAccessActivity();
                }else{
                    GoToBeginActivity();
                }
            }
        }) {
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                HashMap<String, String> headers = new HashMap<String, String>();
                headers.put("X-Requested-With", "XMLHttpRequest");
                return headers;
            }
        };

        HopinApplication.getInstance().addToRequestQueue(jsonObjectRequest);
    }

    private void processResponse(final JSONObject response) {
        try {
            AccessDetails accessDetails = new AccessDetails();
            accessDetails.status = response.optBoolean("status");

            if (accessDetails.status) {
                JSONArray jsonArrayData = response.optJSONArray("data");
                JSONObject jsonObjectData = jsonArrayData.optJSONObject(0);
                accessDetails.id = jsonObjectData.optInt("id");
                accessDetails.clientName = jsonObjectData.optString("client_name");
                accessDetails.email = jsonObjectData.optString("email");
                accessDetails.product = jsonObjectData.optString("product");
                accessDetails.username = jsonObjectData.optString("username");
                SharedHelper.putKey(SplashScreen.this, "access_username", accessDetails.username);
                accessDetails.password = jsonObjectData.optString("password");
                SharedHelper.putKey(SplashScreen.this, "access_password", accessDetails.password );
                accessDetails.passport = jsonObjectData.optString("passport");
                SharedHelper.putKey(SplashScreen.this, "passport", accessDetails.passport);
                accessDetails.clientid = jsonObjectData.optInt("clientid");
                SharedHelper.putKey(SplashScreen.this, "clientid", ""+accessDetails.clientid);
                accessDetails.serviceurl = jsonObjectData.optString("serviceurl");
                SharedHelper.putKey(SplashScreen.this, "serviceurl", accessDetails.serviceurl);
                accessDetails.isActive = jsonObjectData.optInt("is_active");
                accessDetails.createdAt = jsonObjectData.optString("created_at");
                accessDetails.updatedAt = jsonObjectData.optString("updated_at");
                accessDetails.isPaid = jsonObjectData.optInt("is_paid");
                accessDetails.isValid = jsonObjectData.optInt("is_valid");

                JSONObject jsonObjectSettings = response.optJSONObject("setting");

                accessDetails.siteTitle = jsonObjectSettings.optString("site_title");
                SharedHelper.putKey(SplashScreen.this, "app_name", accessDetails.siteTitle);
                accessDetails.siteLogo = jsonObjectSettings.optString("site_logo");
                accessDetails.siteEmailLogo = jsonObjectSettings.optString("site_email_logo");
                accessDetails.siteIcon = jsonObjectSettings.optString("site_icon");
                accessDetails.site_icon = Utilities.drawableFromUrl(SplashScreen.this, accessDetails.siteIcon);
                accessDetails.siteCopyright = jsonObjectSettings.optString("site_copyright");
                accessDetails.providerSelectTimeout = jsonObjectSettings.optString("provider_select_timeout");
                accessDetails.providerSearchRadius = jsonObjectSettings.optString("provider_search_radius");
                accessDetails.basePrice = jsonObjectSettings.optString("base_price");
                accessDetails.pricePerMinute = jsonObjectSettings.optString("price_per_minute");
                accessDetails.taxPercentage = jsonObjectSettings.optString("tax_percentage");
                accessDetails.stripeSecretKey = jsonObjectSettings.optString("stripe_secret_key");
                accessDetails.stripePublishableKey = jsonObjectSettings.optString("stripe_publishable_key");
                SharedHelper.putKey(SplashScreen.this, "stripe_publishable_key", accessDetails.stripePublishableKey);
                accessDetails.cash = jsonObjectSettings.optString("CASH");
                accessDetails.card = jsonObjectSettings.optString("CARD");
                accessDetails.manualRequest = jsonObjectSettings.optString("manual_request");
                accessDetails.defaultLang = jsonObjectSettings.optString("default_lang");
                accessDetails.currency = jsonObjectSettings.optString("currency");
                accessDetails.distance = jsonObjectSettings.optString("distance");
                accessDetails.scheduledCancelTimeExceed = jsonObjectSettings.optString("scheduled_cancel_time_exceed");
                accessDetails.pricePerKilometer = jsonObjectSettings.optString("price_per_kilometer");
                accessDetails.commissionPercentage = jsonObjectSettings.optString("commission_percentage");
                accessDetails.storeLinkAndroid = jsonObjectSettings.optString("store_link_android");
                accessDetails.storeLinkIos = jsonObjectSettings.optString("store_link_ios");
                accessDetails.dailyTarget = jsonObjectSettings.optString("daily_target");
                accessDetails.surgePercentage = jsonObjectSettings.optString("surge_percentage");
                accessDetails.surgeTrigger = jsonObjectSettings.optString("surge_trigger");
                accessDetails.demoMode = jsonObjectSettings.optString("demo_mode");
                accessDetails.bookingPrefix = jsonObjectSettings.optString("booking_prefix");
                accessDetails.sosNumber = jsonObjectSettings.optString("sos_number");
                accessDetails.contactNumber = jsonObjectSettings.optString("contact_number");
                accessDetails.contactEmail = jsonObjectSettings.optString("contact_email");
                accessDetails.socialLogin = jsonObjectSettings.optString("social_login");

                if (AccessDetails.isValid == 1) {
                    if (SharedHelper.getKey(context, "loggedIn").equalsIgnoreCase(context.getResources().getString(R.string.True))) {
                        getProfile();
                    } else {
                        if (isOpened==false){
                            GoToBeginActivity();
                            isOpened = true;
                        }
                    }
                } else {
                    displayMessage(getResources().getString(R.string.demo_expired));
                }
            }else {
                displayMessage(response.optString("message"));

                if (AccessDetails.demo_build){
                    GoToAccessActivity();
                }else{
                    GoToBeginActivity();
                }
            }
        } catch (Exception e){
            e.printStackTrace();
        }

    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        Toast.makeText(activity,"Notification clicked",Toast.LENGTH_SHORT).show();
    }

    public void getProfile(){
           retryCount++;
           Log.e("GetPostAPI",""+AccessDetails.serviceurl + URLHelper.UserProfile+"?device_type=android&device_id="+device_UDID+"&device_token="+device_token);
            JSONObject object = new JSONObject();
            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, AccessDetails.serviceurl +  URLHelper.UserProfile+"" +
                    "?device_type=android&device_id="+device_UDID+"&device_token="+device_token, object , new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {

                    SharedHelper.putKey(context, "id", response.optString("id"));
                    SharedHelper.putKey(context, "first_name", response.optString("first_name"));
                    SharedHelper.putKey(context, "last_name", response.optString("last_name"));
                    SharedHelper.putKey(context, "email", response.optString("email"));
                    if (response.optString("picture").startsWith("http"))
                        SharedHelper.putKey(context, "picture", response.optString("picture"));
                    else
                        SharedHelper.putKey(context, "picture", AccessDetails.serviceurl +"/storage/"+response.optString("picture"));
                    SharedHelper.putKey(context, "gender", response.optString("gender"));
                    SharedHelper.putKey(context, "mobile", response.optString("mobile"));
                    SharedHelper.putKey(context, "wallet_balance", response.optString("wallet_balance"));
                    SharedHelper.putKey(context, "payment_mode", response.optString("payment_mode"));
                    if(!response.optString("currency").equalsIgnoreCase("") && response.optString("currency") != null)
                        SharedHelper.putKey(context, "currency",response.optString("currency"));
                    else
                        SharedHelper.putKey(context, "currency","$");
                    SharedHelper.putKey(context,"sos",response.optString("sos"));
                    Log.e(TAG, "onResponse: Sos Call" + response.optString("sos"));
                    SharedHelper.putKey(context,"loggedIn", context.getResources().getString(R.string.True));
                    GoToMainActivity();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    if (retryCount < 5){
                        getProfile();
                    }else  if (retryCount >= 5){
//                        if (AccessDetails.username.equalsIgnoreCase("") && AccessDetails.passport.equalsIgnoreCase("")){
//                            GoToAccessActivity();
//                        }else{
                            GoToBeginActivity();
//                        }
                    }
                    String json = null;
                    String Message;
                    NetworkResponse response = error.networkResponse;
                    if(response != null && response.data != null){

                        try {
                            JSONObject errorObj = new JSONObject(new String(response.data));

                            if(response.statusCode == 400 || response.statusCode == 405 || response.statusCode == 500){
                                try{
                                    displayMessage(errorObj.optString("message"));
                                }catch (Exception e){
                                    displayMessage(context.getResources().getString(R.string.something_went_wrong));
                                }
                            }else if(response.statusCode == 401){
                                refreshAccessToken();
                            }else if(response.statusCode == 422){

                                json = trimMessage(new String(response.data));
                                if(json !="" && json != null) {
                                    displayMessage(json);
                                }else{
                                    displayMessage(context.getResources().getString(R.string.please_try_again));
                                }

                            }else if(response.statusCode == 503){
                                displayMessage(context.getResources().getString(R.string.server_down));
                            }
                        }catch (Exception e){
                            displayMessage(context.getResources().getString(R.string.something_went_wrong));
                        }

                    } else {
                        if (error instanceof NoConnectionError) {
                            displayMessage(context.getResources().getString(R.string.oops_connect_your_internet));
                        } else if (error instanceof NetworkError) {
                            displayMessage(context.getResources().getString(R.string.oops_connect_your_internet));
                        } else if (error instanceof TimeoutError) {
                            getProfile();
                        }
                    }
                }
            }){
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("X-Requested-With", "XMLHttpRequest");
                    headers.put("Authorization",""+SharedHelper.getKey(context, "token_type")+" "+SharedHelper.getKey(context, "access_token"));
                    return headers;
                }
            };

        HopinApplication.getInstance().addToRequestQueue(jsonObjectRequest);
        }


    @Override
    protected void onDestroy() {
        handleCheckStatus.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    private void refreshAccessToken() {
            JSONObject object = new JSONObject();
            try {
                object.put("grant_type", "refresh_token");
                object.put("client_id", AccessDetails.clientid);
                object.put("client_secret", AccessDetails.passport);
                object.put("refresh_token", SharedHelper.getKey(context, "refresh_token"));
                object.put("scope", "");
            } catch (JSONException e) {
                e.printStackTrace();
            }

            JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.POST, AccessDetails.serviceurl + URLHelper.login, object, new Response.Listener<JSONObject>() {
                @Override
                public void onResponse(JSONObject response) {
                    Log.v("SignUpResponse", response.toString());
                    SharedHelper.putKey(context, "access_token", response.optString("access_token"));
                    SharedHelper.putKey(context, "refresh_token", response.optString("refresh_token"));
                    SharedHelper.putKey(context, "token_type", response.optString("token_type"));
                    getProfile();
                }
            }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    String json = null;
                    String Message;
                    NetworkResponse response = error.networkResponse;

                    if (response != null && response.data != null) {
                        SharedHelper.putKey(context,"loggedIn", context.getResources().getString(R.string.False));
//                        if (AccessDetails.username.equalsIgnoreCase("") && AccessDetails.passport.equalsIgnoreCase("")){
//                            GoToAccessActivity();
//                        }else{
                            GoToBeginActivity();
//                        }
                    } else {
                        if (error instanceof NoConnectionError) {
                            displayMessage(context.getResources().getString(R.string.oops_connect_your_internet));
                        } else if (error instanceof NetworkError) {
                            displayMessage(context.getResources().getString(R.string.oops_connect_your_internet));
                        } else if (error instanceof TimeoutError) {
                            refreshAccessToken();
                        }
                    }
                }
            }) {
                @Override
                public Map<String, String> getHeaders() throws AuthFailureError {
                    HashMap<String, String> headers = new HashMap<String, String>();
                    headers.put("X-Requested-With", "XMLHttpRequest");
                    return headers;
                }
            };

        HopinApplication.getInstance().addToRequestQueue(jsonObjectRequest);

    }

    @Override
    protected void onPause() {
        super.onPause();
    }

    public void GoToMainActivity(){
        Intent mainIntent = new Intent(activity, MainActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(mainIntent);
        activity.finish();
    }

    public void GoToBeginActivity(){
        Intent mainIntent = new Intent(activity, WelcomeScreenActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(mainIntent);
        activity.finish();
    }

    public void GoToAccessActivity(){
        Intent mainIntent = new Intent(activity, AccessKeyActivity.class);
        mainIntent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK | Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(mainIntent);
        activity.finish();
    }

    public void displayMessage(String toastString){
        Log.e("displayMessage",""+toastString);
        Toast.makeText(activity, toastString, Toast.LENGTH_SHORT).show();
    }

    public void GetToken() {
        try {
            if(!SharedHelper.getKey(context,"device_token").equals("") && SharedHelper.getKey(context,"device_token") != null) {
                device_token = SharedHelper.getKey(context, "device_token");
                Log.i(TAG, "GCM Registration Token: " + device_token);
            }else{
                device_token = ""+ FirebaseInstanceId.getInstance().getToken();
                SharedHelper.putKey(context, "device_token",""+FirebaseInstanceId.getInstance().getToken());
                Log.i(TAG, "Failed to complete token refresh: " + device_token);
            }
        }catch (Exception e) {
            device_token = "COULD NOT GET FCM TOKEN";
            Log.d(TAG, "Failed to complete token refresh", e);
        }

        try {
            device_UDID = android.provider.Settings.Secure.getString(getContentResolver(), android.provider.Settings.Secure.ANDROID_ID);
            Log.i(TAG, "Device UDID:" + device_UDID);
        }catch (Exception e) {
            device_UDID = "COULD NOT GET UDID";
            e.printStackTrace();
            Log.d(TAG, "Failed to complete device UDID");
        }
    }

    private void showDialog()
    {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setMessage(context.getResources().getString(R.string.connect_to_network))
                .setCancelable(false)
                .setPositiveButton(context.getResources().getString(R.string.connect_to_wifi), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
                    }
                })
                .setNegativeButton(context.getResources().getString(R.string.quit), new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int id) {
                        finish();
                    }
                });
        if(alert == null){
            alert = builder.create();
            alert.show();
        }
    }

//
//    @Override
//    public void onUpdateNeeded(final String updateUrl) {
//        AlertDialog dialog = new AlertDialog.Builder(this)
//                .setTitle(getResources().getString(R.string.new_version_available))
//                .setMessage(getResources().getString(R.string.update_to_continue))
//                .setPositiveButton(getResources().getString(R.string.update),
//                        new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                redirectStore(updateUrl);
//                            }
//                        }).setNegativeButton(getResources().getString(R.string.no_thanks),
//                        new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialog, int which) {
//                                finish();
//                            }
//                        }).create();
//        dialog.show();
//    }
//
//    private void redirectStore(String updateUrl) {
//        final Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(updateUrl));
//        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
//        startActivity(intent);
//    }

}
