@extends('user.layout.app')

@section('content')
<div class="row gray-section no-margin">
    <div class="container">
        <div class="content-block">
            <h2>{{ $title }}</h2>
            <div class="title-divider"></div>
            <p>
               @if($page == 'page_privacy')
                    <iframe width="100%" style="height: 95vh" src="https://app.termly.io/document/privacy-policy/f33ba9be-cd0f-49e9-a137-89b19cf256f7" frameborder="0" allowfullscreen>
                        <p>Your browser does not support iframes.</p>
                    </iframe>
                @elseif($page == 'terms')
                    <iframe width="100%" style="height: 95vh" src="https://app.termly.io/document/terms-of-use-for-website/ae520463-fb91-4ff4-aef3-c2ae07a769d3" frameborder="0" allowfullscreen>
                        <p>Your browser does not support iframes.</p>
                    </iframe>
                @elseif($page == 'cookie')
                    <iframe width="100%" style="height: 95vh" src="https://app.termly.io/document/cookie-policy/f866a063-f2f8-4838-9f0d-812ba763d388" frameborder="0" allowfullscreen>
                        <p>Your browser does not support iframes.</p>
                    </iframe>
                @elseif($page == 'disclaimer')
                    <iframe width="100%" style="height: 95vh" src="https://app.termly.io/document/disclaimer/ebc8da5c-358f-4403-b6f2-230d83f6fb8e" frameborder="0" allowfullscreen>
                        <p>Your browser does not support iframes.</p>
                    </iframe>
                @endif
            </p>
        </div>
    </div>
</div>
@endsection